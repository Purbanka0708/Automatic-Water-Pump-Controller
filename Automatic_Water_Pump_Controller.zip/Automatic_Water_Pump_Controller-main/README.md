# Automatic Water Pump Controller – Arduino-Based Water Level Management

## Project Overview
This project implements a smart water pump control system using an Arduino Uno and an ultrasonic sensor (HC-SR04). It automates the process of filling a water tank by turning the pump ON when the water level is low and OFF when the tank is full. This solution helps conserve water, saves energy, and minimizes manual intervention, making it ideal for homes, hostels, agriculture, and small industries.

## Key Features
- **Ultrasonic water level sensing** using HC-SR04  
- **Automatic relay control** for switching the pump  
- **Real-time distance monitoring** via Serial Monitor  
- **Safe & low-power setup** for continuous operation  
- **Compact and cost-effective design**

## Components Used
- Arduino Uno (ATmega328P)  
- Ultrasonic Sensor HC-SR04  
- 5V Single-Channel Relay Module  
- DC Submersible Water Pump (5V)  
- Breadboard and jumper wires  
- USB power supply  
- Plastic pipes and water containers  

## How It Works
1. **Distance Measurement**: HC-SR04 measures the distance between the sensor and the water surface.  
2. **Threshold Logic**:
   - If distance > 15 cm (tank low): Pump turns ON.
   - If distance < 5 cm (tank full): Pump turns OFF.
3. The relay acts as a switch between Arduino and the water pump.  
4. Serial Monitor displays real-time tank distance and pump status.  

## Project Structure
```
automatic-water-pump-controller/  
├── ArduinoCode/  
│   └── water_pump_controller.ino  
├── CircuitDiagram/  
│   ├── circuit_connection.png
│   └── project_setup.png  
├── Documentation/  
│   └── Water_Pump_Report.pdf  
└── README.md  
```

## Getting Started
1. **Connections**:
   - **Ultrasonic Sensor**:  
     - VCC → 5V  
     - GND → GND  
     - TRIG → D9  
     - ECHO → D10  
   - **Relay Module**:  
     - VCC → 5V  
     - GND → GND  
     - IN → D8  
   - **Pump Control**:  
     - Connect pump via relay NO and COM terminals with external 5V supply.

2. **Upload the code** to Arduino Uno via USB.  
3. **Power up** the circuit and monitor readings using the Arduino Serial Monitor.  
4. **Test the system** by changing water levels manually and observing pump behavior.

## Applications
- Domestic overhead tank automation  
- Hostel and apartment water management  
- Agricultural irrigation reservoir control  
- Industrial water storage systems  

## Future Improvements
- Add GSM/Wi-Fi modules for remote monitoring  
- Mobile app notifications and manual override  
- Support for multiple tanks  
- Solar-powered version for remote areas  
- LCD/OLED display for tank level and status  

## Contributors
- Dhritiman Roy  

## License
This project is open-source and available under the MIT License.

## Acknowledgments
Special thanks to my sister for her unwavering support and help in report preparation, as well as to the National Institute of Technology Agartala for academic guidance.
